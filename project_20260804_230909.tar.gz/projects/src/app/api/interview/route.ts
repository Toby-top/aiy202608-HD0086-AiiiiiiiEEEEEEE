import { NextResponse } from 'next/server';
import type { InterviewRequest } from '@/types/interview';

/**
 * AI 面试官 API - 腾讯会议风格
 * 返回 [MEETING_CTRL] 格式的 JSON，驱动前端界面更新
 */

// 面试阶段类型
type InterviewStage = 'ice_breaking' | 'academics' | 'critical_thinking' | 'wrap_up';

// MEETING_CTRL 响应类型
interface MeetingCtrlResponse {
  action: 'ask' | 'follow_up' | 'end';
  host_name: string;
  speech_text: string;
  subtitle_text: string;
  chat_bubble: string;
  ai_minutes: string;
  mic_status: 'on' | 'off';
  video_status: 'on' | 'off';
  language_mode: 'en' | 'zh';
  current_stage: InterviewStage;
  score_hidden: {
    fluency: number;
    logic: number;
    confidence: number;
  };
}

// 面试官名称
const HOST_NAME = '王老师';

// 面试问题库（中英双语）
const INTERVIEW_QUESTIONS: Record<InterviewStage, { en: string; zh: string; aiMinutes: string }[]> = {
  ice_breaking: [
    {
      en: 'Good morning! Welcome to this interview. Could you please introduce yourself briefly and tell me about your favorite subject in school?',
      zh: '早上好！欢迎参加这次面试。请简单介绍一下自己，并告诉我你最喜欢的学科是什么？',
      aiMinutes: '【破冰阶段】面试官自我介绍，询问学生 favorite subject',
    },
    {
      en: 'That\'s interesting! What do you usually like to do on weekends? Do you have any hobbies or extracurricular activities?',
      zh: '很有趣！你周末通常喜欢做什么？有什么爱好或课外活动吗？',
      aiMinutes: '【破冰阶段】了解学生兴趣爱好和课外活动',
    },
  ],
  academics: [
    {
      en: 'Now let\'s talk about academics. How do you think you can use mathematics to solve real-world problems? Can you give me an example?',
      zh: '现在我们来谈谈学术方面。你认为如何用数学解决现实问题？能举个例子吗？',
      aiMinutes: '【学术阶段】探讨数学在实际生活中的应用',
    },
    {
      en: 'Great thinking! What\'s your favorite book or article that recently changed your perspective? Why did it impact you?',
      zh: '很好的思考！最近有什么书或文章改变了你的观点？为什么它对你有影响？',
      aiMinutes: '【学术阶段】了解学生的阅读习惯和思维深度',
    },
  ],
  critical_thinking: [
    {
      en: 'Let\'s discuss a controversial topic. Do you think schools should ban mobile phones? Why or why not?',
      zh: '让我们讨论一个有争议的话题。你认为学校应该禁止手机吗？为什么？',
      aiMinutes: '【批判性思维】讨论手机禁令，考察学生辩证思维',
    },
    {
      en: 'That\'s a thoughtful answer. If you could change one thing about your school, what would it be and why?',
      zh: '很有深度的回答。如果你能改变学校的一件事，会是什么？为什么？',
      aiMinutes: '【批判性思维】探讨学生对教育的理解和改进建议',
    },
  ],
  wrap_up: [
    {
      en: 'We\'re almost done. Do you have any questions you\'d like to ask about our school or the program?',
      zh: '我们快结束了。你有什么想问关于我们学校或项目的问题吗？',
      aiMinutes: '【收尾阶段】学生提问环节',
    },
    {
      en: 'Thank you for your time today. It was great talking with you. Have a wonderful day!',
      zh: '感谢你今天的时间。很高兴和你交流。祝你有美好的一天！',
      aiMinutes: '【面试结束】面试官致结束语',
    },
  ],
};

// 根据学生回答长度评估流畅度
function evaluateFluency(message: string): number {
  const wordCount = message.trim().split(/\s+/).length;
  if (wordCount >= 20) return 5;
  if (wordCount >= 10) return 4;
  if (wordCount >= 5) return 3;
  if (wordCount >= 2) return 2;
  return 1;
}

// 检测学生使用的语言
function detectLanguage(message: string): 'en' | 'zh' {
  const chineseChars = message.match(/[\u4e00-\u9fff]/g);
  const chineseRatio = chineseChars ? chineseChars.length / message.length : 0;
  return chineseRatio > 0.3 ? 'zh' : 'en';
}

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = (await request.json()) as InterviewRequest;
    const { interviewType, message, history } = body;

    // 参数验证
    if (!interviewType || !message) {
      return NextResponse.json(
        { success: false, error: '缺少必要参数' },
        { status: 400 }
      );
    }

    // 检测学生使用的语言
    const studentLanguage = detectLanguage(message);

    // 计算当前阶段和问题索引
    const historyLength = history?.length ?? 0;
    const questionIndex = Math.floor(historyLength / 2) % 2;
    
    // 根据历史长度确定阶段
    let currentStage: InterviewStage = 'ice_breaking';
    if (historyLength >= 6) {
      currentStage = 'wrap_up';
    } else if (historyLength >= 4) {
      currentStage = 'critical_thinking';
    } else if (historyLength >= 2) {
      currentStage = 'academics';
    }

    // 获取问题（面试官始终使用英文）
    const questions = INTERVIEW_QUESTIONS[currentStage];
    const questionData = questions[questionIndex] ?? questions[0];
    const question = questionData.en; // 面试官始终使用英文
    const languageMode = 'en'; // 语言模式显示为英文

    // 评估学生回答
    const fluency = evaluateFluency(message);
    const logic = Math.min(5, Math.floor(Math.random() * 2) + 3);
    const confidence = Math.min(5, Math.floor(Math.random() * 2) + 3);

    // 判断是否结束
    const isEnd = currentStage === 'wrap_up' && questionIndex >= 1;

    // 构建 chat_bubble
    const chatBubble = isEnd
      ? `**${HOST_NAME}**: ${question}\n\n---\n**面试结束** - 综合评语：表现良好，${studentLanguage === 'zh' ? '中文表达流畅' : '英语流利'}，逻辑思维清晰，继续保持！`
      : `**${HOST_NAME}**: ${question}`;

    // 构建响应
    const response: MeetingCtrlResponse = {
      action: isEnd ? 'end' : questionIndex === 0 ? 'ask' : 'follow_up',
      host_name: HOST_NAME,
      speech_text: question,
      subtitle_text: question,
      chat_bubble: chatBubble,
      ai_minutes: questionData.aiMinutes,
      mic_status: 'on',
      video_status: 'on',
      language_mode: languageMode,
      current_stage: currentStage,
      score_hidden: {
        fluency,
        logic,
        confidence,
      },
    };

    // 返回 [MEETING_CTRL] 格式的响应
    const meetingCtrlString = `[MEETING_CTRL]${JSON.stringify(response)}`;
    
    return NextResponse.json({
      success: true,
      data: {
        reply: meetingCtrlString,
        messageId: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        meetingCtrl: response,
      },
    });
  } catch {
    return NextResponse.json(
      { success: false, error: '服务器内部错误' },
      { status: 500 }
    );
  }
}
