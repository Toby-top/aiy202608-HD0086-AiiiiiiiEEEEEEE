import { NextRequest, NextResponse } from 'next/server';
import { ASRClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

/**
 * ASR 语音转文字 API
 * 接收前端录音 Blob，调用 ASR SDK 进行语音识别
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const formData = await request.formData();
    const audioFile = formData.get('audio') as File | null;

    if (!audioFile) {
      return NextResponse.json(
        { success: false, error: '缺少音频文件' },
        { status: 400 }
      );
    }

    // 验证文件类型
    const allowedTypes = ['audio/webm', 'audio/wav', 'audio/mp3', 'audio/m4a', 'audio/ogg', 'audio/mpeg'];
    if (!allowedTypes.includes(audioFile.type) && !audioFile.type.startsWith('audio/')) {
      return NextResponse.json(
        { success: false, error: '不支持的音频格式' },
        { status: 400 }
      );
    }

    // 验证文件大小（≤ 100MB）
    if (audioFile.size > 100 * 1024 * 1024) {
      return NextResponse.json(
        { success: false, error: '音频文件过大，请控制在 100MB 以内' },
        { status: 400 }
      );
    }

    // 将音频文件转换为 base64
    const arrayBuffer = await audioFile.arrayBuffer();

    if (arrayBuffer.byteLength === 0) {
      return NextResponse.json(
        { success: false, error: '音频文件为空' },
        { status: 400 }
      );
    }

    const base64Data = Buffer.from(arrayBuffer).toString('base64');

    // 提取转发头信息
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // 调用 ASR SDK
    const config = new Config();
    const client = new ASRClient(config, customHeaders);

    let result;
    try {
      result = await client.recognize({
        uid: `interview-user-${Date.now()}`,
        base64Data,
      });
    } catch (asrError) {
      // 处理"无有效语音"的情况 — 这是正常业务场景，不是错误
      const errMsg =
        asrError instanceof Error ? asrError.message : String(asrError);
      if (
        errMsg.includes('no valid speech') ||
        errMsg.includes('20000003') ||
        errMsg.includes('silence')
      ) {
        return NextResponse.json({
          success: true,
          data: {
            text: '',
            duration: undefined,
          },
          message: '未检测到有效语音',
        });
      }
      throw asrError;
    }

    return NextResponse.json({
      success: true,
      data: {
        text: result.text || '',
        duration: result.duration,
      },
    });
  } catch (error) {
    console.error('ASR Error:', error);

    const errorMessage =
      error instanceof Error ? error.message : '语音识别服务异常';

    return NextResponse.json(
      { success: false, error: errorMessage },
      { status: 500 }
    );
  }
}
