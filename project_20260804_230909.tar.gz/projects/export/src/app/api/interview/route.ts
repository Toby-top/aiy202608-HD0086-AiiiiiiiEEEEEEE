import { NextResponse } from 'next/server';
import type { InterviewRequest } from '@/types/interview';

/**
 * AI 面试官 API - 腾讯会议风格
 * 返回 [UI_CMD] 格式的 JSON，驱动前端界面更新
 */

// 面试阶段类型
type InterviewStage = 'ice_breaking' | 'academics' | 'critical_thinking' | 'wrap_up';

// UI_CMD 响应类型
interface UICmdResponse {
  action: 'ask' | 'follow_up' | 'end';
  speaker_name: string;
  speech_text: string;
  subtitle_text: string;
  chat_bubble: string;
  mic_status: 'on' | 'off';
  camera_status: 'on' | 'off';
  current_stage: InterviewStage;
  score_hidden: {
    fluency: number;
    logic: number;
    confidence: number;
  };
}

// 面试问题库
const INTERVIEW_QUESTIONS: Record<InterviewStage, string[]> = {
  ice_breaking: [
    'Good morning! Could you please briefly introduce yourself and tell me about your favorite subject?',
    'That\'s great! What do you usually like to do on weekends? Do you have any hobbies or extracurricular activities?',
  ],
  academics: [
    'Now let\'s talk about academics. How do you think you can use mathematics to solve real-world problems? Can you give me an example?',
    'Interesting perspective. What\'s your favorite book or article that recently changed your perspective? Why did it impact you?',
  ],
  critical_thinking: [
    'Let\'s discuss a controversial topic. Do you think schools should ban mobile phones? Why or why not?',
    'That\'s a thoughtful answer. Here\'s another question: If you could change one thing about your school, what would it be and why?',
  ],
  wrap_up: [
    'We\'re almost done. Do you have any questions you\'d like to ask about our school?',
    'Thank you for your time today. It was great talking with you. Have a wonderful day!',
  ],
};

// 根据学生回答长度评估流畅度
function evaluateFluency(message: string): number {
  const wordCount = message.trim().split(/\s+/).length;
  if (wordCount >= 20) return 5;
  if (wordCount >= 10) return 4;
  if (wordCount >= 5) return 3;
  if (wordCount >= 2) return 2;
  return 1;
}

// 获取下一阶段
function getNextStage(currentStage: InterviewStage, questionIndex: number): InterviewStage {
  if (questionIndex >= 1) {
    const stageOrder: InterviewStage[] = ['ice_breaking', 'academics', 'critical_thinking', 'wrap_up'];
    const currentIndex = stageOrder.indexOf(currentStage);
    if (currentIndex < stageOrder.length - 1) {
      return stageOrder[currentIndex + 1];
    }
  }
  return currentStage;
}

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = (await request.json()) as InterviewRequest;
    const { interviewType, message, history } = body;

    // 参数验证
    if (!interviewType || !message) {
      return NextResponse.json(
        { success: false, error: '缺少必要参数' },
        { status: 400 }
      );
    }

    // 计算当前阶段和问题索引
    const historyLength = history?.length ?? 0;
    const questionIndex = Math.floor(historyLength / 2) % 2;
    
    // 根据历史长度确定阶段
    let currentStage: InterviewStage = 'ice_breaking';
    if (historyLength >= 6) {
      currentStage = 'wrap_up';
    } else if (historyLength >= 4) {
      currentStage = 'critical_thinking';
    } else if (historyLength >= 2) {
      currentStage = 'academics';
    }

    // 获取问题
    const questions = INTERVIEW_QUESTIONS[currentStage];
    const question = questions[questionIndex] ?? questions[0];

    // 评估学生回答
    const fluency = evaluateFluency(message);
    const logic = Math.min(5, Math.floor(Math.random() * 2) + 3); // 3-4 分
    const confidence = Math.min(5, Math.floor(Math.random() * 2) + 3); // 3-4 分

    // 判断是否结束
    const isEnd = currentStage === 'wrap_up' && questionIndex >= 1;

    // 构建 chat_bubble
    const chatBubble = isEnd
      ? `**Mr. Thompson**: ${question}\n\n---\n**面试结束** - 综合评语：表现良好，英语流利，逻辑思维清晰，继续保持！`
      : `**Mr. Thompson**: ${question}`;

    // 构建响应
    const response: UICmdResponse = {
      action: isEnd ? 'end' : questionIndex === 0 ? 'ask' : 'follow_up',
      speaker_name: 'Mr. Thompson',
      speech_text: question,
      subtitle_text: question,
      chat_bubble: chatBubble,
      mic_status: 'on',
      camera_status: 'on',
      current_stage: currentStage,
      score_hidden: {
        fluency,
        logic,
        confidence,
      },
    };

    // 返回 [UI_CMD] 格式的响应
    const uiCmdString = `[UI_CMD]${JSON.stringify(response)}`;
    
    return NextResponse.json({
      success: true,
      data: {
        reply: uiCmdString,
        messageId: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        uiCmd: response,
      },
    });
  } catch {
    return NextResponse.json(
      { success: false, error: '服务器内部错误' },
      { status: 500 }
    );
  }
}
