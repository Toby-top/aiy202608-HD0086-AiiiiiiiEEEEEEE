# 项目上下文

### 版本技术栈

- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI 组件**: shadcn/ui (基于 Radix UI)
- **Styling**: Tailwind CSS 4

## 目录结构

```
├── public/                 # 静态资源
├── scripts/                # 构建与启动脚本
│   ├── build.sh            # 构建脚本
│   ├── dev.sh              # 开发环境启动脚本
│   ├── prepare.sh          # 预处理脚本
│   └── start.sh            # 生产环境启动脚本
├── src/
│   ├── app/                # 页面路由与布局
│   ├── components/ui/      # Shadcn UI 组件库
│   ├── hooks/              # 自定义 Hooks
│   ├── lib/                # 工具库
│   │   └── utils.ts        # 通用工具函数 (cn)
│   └── server.ts           # 自定义服务端入口
├── next.config.ts          # Next.js 配置
├── package.json            # 项目依赖管理
└── tsconfig.json           # TypeScript 配置
```

- 项目文件（如 app 目录、pages 目录、components 等）默认初始化到 `src/` 目录下。

## 包管理规范

**仅允许使用 pnpm** 作为包管理器，**严禁使用 npm 或 yarn**。
**常用命令**：
- 安装依赖：`pnpm add <package>`
- 安装开发依赖：`pnpm add -D <package>`
- 安装所有依赖：`pnpm install`
- 移除依赖：`pnpm remove <package>`

## 开发规范

### 编码规范

- 默认按 TypeScript `strict` 心智写代码；优先复用当前作用域已声明的变量、函数、类型和导入，禁止引用未声明标识符或拼错变量名。
- 禁止隐式 `any` 和 `as any`；函数参数、返回值、解构项、事件对象、`catch` 错误在使用前应有明确类型或先完成类型收窄，并清理未使用的变量和导入。

### next.config 配置规范

- 配置的路径不要写死绝对路径，必须使用 path.resolve(__dirname, ...)、import.meta.dirname 或 process.cwd() 动态拼接。

### Hydration 问题防范

1. 严禁在 JSX 渲染逻辑中直接使用 typeof window、Date.now()、Math.random() 等动态数据。**必须使用 'use client' 并配合 useEffect + useState 确保动态内容仅在客户端挂载后渲染**；同时严禁非法 HTML 嵌套（如 <p> 嵌套 <div>）。
2. **禁止使用 head 标签**，优先使用 metadata，详见文档：https://nextjs.org/docs/app/api-reference/functions/generate-metadata
   1. 三方 CSS、字体等资源可在 `globals.css` 中顶部通过 `@import` 引入或使用 next/font
   2. preload, preconnect, dns-prefetch 通过 ReactDOM 的 preload、preconnect、dns-prefetch 方法引入
   3. json-ld 可阅读 https://nextjs.org/docs/app/guides/json-ld

## UI 设计与组件规范 (UI & Styling Standards)

- 模板默认预装核心组件库 `shadcn/ui`，位于`src/components/ui/`目录下
- Next.js 项目**必须默认**采用 shadcn/ui 组件、风格和规范，**除非用户指定用其他的组件和规范。**

## 项目概览

AI 国际高中面试辅导系统 — 帮助学生模拟国际高中面试（Common App / 校友面试 / Initialview），提供语音对话、实时评分、面试回放等功能。

## 目录结构（扩展）

```
src/
├── app/
│   ├── page.tsx                    # 首页 - 三种面试类型选择
│   ├── interview/[type]/page.tsx   # 面试页 - 对话界面 + 录音
│   ├── result/[id]/page.tsx        # 结果等待页 - AI 分析进度
│   ├── report/[id]/page.tsx        # 报告页 - 评分与改进建议
│   └── api/interview/route.ts      # 面试对话 API（预留 Coze 对接）
├── components/
│   ├── ui/                         # shadcn/ui 组件
│   └── interview/                  # 面试业务组件
│       ├── InterviewCard.tsx       # 面试类型卡片
│       ├── ChatBubble.tsx         # 对话气泡（已弃用，改用 VoiceMessage）
│       ├── VoiceMessage.tsx       # 语音条组件（播放/暂停、波形、右键转文字）
│       ├── TimerDisplay.tsx       # 计时器显示
│       ├── RecordButton.tsx       # 录音按钮（含波形可视化）
│       ├── AudioPlayer.tsx        # 音频播放器（进度条/倍速/音量）
│       └── Timeline.tsx           # 面试回放时间轴（含 AI 标注）
├── hooks/
│   ├── useAudioRecorder.ts        # Web Audio API 录音 Hook
│   ├── useTimer.ts                # 计时器 Hook
│   └── use-mobile.ts              # 移动端检测
├── types/
│   └── interview.ts               # 面试相关类型定义
└── lib/
    ├── utils.ts                   # 通用工具 (cn)
    └── interview-config.ts        # 面试类型配置与工具函数
```

## 关键文件定位

| 功能 | 文件路径 |
|------|----------|
| 面试类型配置 | `src/lib/interview-config.ts` |
| 录音功能 | `src/hooks/useAudioRecorder.ts` |
| 面试对话 API | `src/app/api/interview/route.ts` |
| ASR 语音转文字 API | `src/app/api/asr/route.ts` |
| 类型定义 | `src/types/interview.ts` |
| 模拟回放数据 | `src/lib/mockInterview.ts` |
| 设计规范 | `DESIGN.md` |

## 后续开发指引

- **Coze API 对接**：在 `src/app/api/interview/route.ts` 中接入 Coze Bot API，替换 mock 回复
- ~~**语音转文字**~~：已集成 ASR 服务（`/api/asr`），使用 `coze-coding-dev-sdk` 的 `ASRClient`
- ~~**雷达图**~~：报告页已预留雷达图占位区域
- ~~**面试回放**~~：已实现，包含 AudioPlayer 播放器 + Timeline 时间轴 + AI 标注
- **真实评分**：接入 AI 评分接口替换 `mockResult` 数据
