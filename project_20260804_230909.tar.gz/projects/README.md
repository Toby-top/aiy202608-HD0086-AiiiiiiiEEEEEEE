# AI 国际高中面试辅导系统

基于 Next.js + TypeScript + Tailwind CSS 开发的 AI 面试辅导系统。

## 功能特性

- 多种面试类型（Common App / 校友面试 / Initialview）
- 语音对话与录音功能
- AI 实时评分与报告生成
- 面试回放与时间轴
- AI 自动标注（语速/情绪/关键问题）
- 雷达图多维度评分展示

## 技术栈

- Next.js 14+ App Router
- TypeScript
- Tailwind CSS
- Web Audio API
- ECharts

## 快速开始

```bash
npm install
npm run dev
```
